g++ plus.cpp

# do sth
echo 122,5,10,147 > res.out
echo 5/10 passed.fail > res.txt

rm a.out
